sh = float(input('quanto voce ganha por hora: '))
ht = int(input('quantas horas voce trabalha por mes: '))

s = ht * sh

print(f'seu salario eh de: {s} reais por mes')
