s = 0

for i in range(5):
    num = int(input('digite um numero: '))
    s = s + num

s = s / 5

print(f'a media dos numeros eh: {s}')