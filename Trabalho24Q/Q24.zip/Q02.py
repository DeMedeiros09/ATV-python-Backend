n1 = int(input('digite sua primeira nota: '))
n2 = int(input('digite sua segunda nota: '))
n3 = int(input('digite sua terceira nota: '))
n4 = int(input('digite sua quarta nota: '))

m = (n1 + n2 + n3 + n4)/4

print(f'sua nota éh: {m}')