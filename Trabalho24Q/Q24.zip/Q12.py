l = input('digite uma letra: ')

if l == 'a' or l == 'e' or l == 'i' or l == 'o' or l == 'u':
    print(f'a letra ({l}) é uma vogal') 
else:
    print(f'a letra ({l}) é uma consoante')