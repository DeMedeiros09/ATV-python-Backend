n1 = int(input('digite um numero: '))
n2 = int(input('digite um numero: '))

for i in range(n1+1,n2):
    print(i)