def posinega(num):
    if num >= 0:
        print(f'{num} eh positivo')
    else:
        print(f'{num} eh negativo')
posinega(100)