f = int(input('digite a temperatura em Fahrenheit para a convercao em Celcios: '))

c = 5 * ((f-32) / 9)

print(f'a temperatura de {f:.2f}F° Fahrenheit em celcios eh: {c:.2f}C°')