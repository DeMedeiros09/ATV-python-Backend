num = int(input('digite um valor qualquer: '))

if num >= 0:
    print(f'o valor {num} eh positivo')
else:
    print(f'o valor {num} eh negativo')