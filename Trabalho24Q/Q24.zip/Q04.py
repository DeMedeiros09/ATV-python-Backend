import math
r = float(input('digite a medida de um raio de uma circunferencia: '))

a = math.pi * r**2

print(f'a area docirculo com base no raio {r:.2f} eh: {a:.2f}')