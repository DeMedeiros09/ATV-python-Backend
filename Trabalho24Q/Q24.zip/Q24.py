nome = input('digite um nome: ')

tanto = len(nome)

for i in nome:
    print(i)
