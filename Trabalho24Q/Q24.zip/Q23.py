nomee = input('digite seu nome: ')

nomee = nomee.upper()

nomee = nomee[::-1]

print(nomee)