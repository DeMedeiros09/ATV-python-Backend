b = float(input('digite a medicao da base do triangulo: '))
h = float(input('digite a medicao da altura do triangulo: '))

a = b * h

print(f'a area do triangulo eh: {a}. E o seu dobro eh: {a*2}')