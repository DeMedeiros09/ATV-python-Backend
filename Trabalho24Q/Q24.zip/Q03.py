m = float(input('digite uma medida em metros: '))

c = m * 100

print(f'a sua medicao de {m}m eh em centimetros: {c}cm')