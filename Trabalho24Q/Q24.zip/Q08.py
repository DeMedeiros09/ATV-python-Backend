c = float(input('digite a temperatura em Celcios para a convercao em Fahrenheit: '))

f = (c * 1.8) + 32

print(f'a temperatura de {c:.2f}C° Celcios em Fahrenheit eh: {f:.2f}F°')