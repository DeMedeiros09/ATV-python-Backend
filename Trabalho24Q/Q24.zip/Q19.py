def soma(a,b,c):
    s = a + b + c
    return s

print(soma (1,10,11))